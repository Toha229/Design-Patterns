﻿//              2.2
#include "Barrack.h"

int main()
{
	MilitaryBarracks mb;
	mb.planUnit(20, 15);
	mb.planUnit(10, 30);
	
	MedicalBarracks meb;
	meb.planUnit(5, 5);
}